package es.ies.puerto.biblioteca;

public class Categoria {
    public String nombre;
    public String descripcion;

    public boolean agregarCategoria(){
        return true;
    }
    public boolean listarLibrosPorCategoria(){
        return true;
    }
}
