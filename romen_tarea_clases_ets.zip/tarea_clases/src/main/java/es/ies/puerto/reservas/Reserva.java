package es.ies.puerto.reservas;

public class Reserva {
    public String fechaEntrada;
    public String fechaSalida;
    public Cliente cliente;
    public Habitacion habitacion;

    public float calcularCostoTotal(){
        return 0f;
    }
    public boolean confirmarReserva(){
        return true;
    }
}
