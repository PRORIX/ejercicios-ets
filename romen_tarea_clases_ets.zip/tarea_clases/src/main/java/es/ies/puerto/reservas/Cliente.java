package es.ies.puerto.reservas;

public class Cliente {
    public String nombre;
    public int numeroContacto;
    public String correoElectronico;

    public boolean registrarCliente(){
        return true;
    }
    public String obtenerInformacion(){
        return "";
    }
}
