package es.ies.puerto.biblioteca;

public class SalaLectura {
    public String nombre;
    public String direccion;

    public boolean reservarSala(){
        return true;
    }
    public boolean verificarDisponibilidad(){
        return true;
    }
}
