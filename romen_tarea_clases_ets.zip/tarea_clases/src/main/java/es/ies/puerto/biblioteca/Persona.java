package es.ies.puerto.biblioteca;

public class Persona {
    public String id;
    public String nombre;
}
