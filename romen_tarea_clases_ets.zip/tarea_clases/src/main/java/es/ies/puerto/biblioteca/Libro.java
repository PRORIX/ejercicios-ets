package es.ies.puerto.biblioteca;

public class Libro {
    public String ISBN;
    public String titulo;
    public String autor;
    public Categoria categoria;

    public boolean verificarDisponibilidad(){
        return true;
    }
    public boolean asignarCategoria(){
        return true;
    }
}
