package es.ies.puerto.biblioteca;

public class Prestamo {
    public Miembro miembro;
    public String fecha;
    public String fechaDevolucion;
    public Libro libro;

    public boolean calcularMultaPorRetraso(){
        return true;
    }
    public boolean marcarComoDevuelto(){
        return true;
    }
}
