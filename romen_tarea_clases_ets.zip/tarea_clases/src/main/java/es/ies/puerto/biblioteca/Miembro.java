package es.ies.puerto.biblioteca;
import java.util.List;


public class Miembro extends Persona{
    public Persona miembro;
    public List<Prestamo> historialPrestamos;

    public boolean registrarMiembro(){
        return true;
    }
    public boolean verHistorial(){
        return true;
    }
}

