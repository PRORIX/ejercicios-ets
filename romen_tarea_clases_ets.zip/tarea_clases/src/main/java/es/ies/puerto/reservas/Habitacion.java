package es.ies.puerto.reservas;

public class Habitacion {
    public int numero;
    public String tipo;
    public float precioPorNoche;

    public boolean comprobarDisponibilidad(){
        return true;
    }
    public boolean cambiarEstado(){
        return true;
    }
}
