package es.ies.puerto.biblioteca;

public class Bibliotecario extends Persona{
    public Persona bibliotecario;
    public boolean registrarLibros(){
        return true;
    }
    public boolean gestionarPrestamos(){
        return true;
    }
}
